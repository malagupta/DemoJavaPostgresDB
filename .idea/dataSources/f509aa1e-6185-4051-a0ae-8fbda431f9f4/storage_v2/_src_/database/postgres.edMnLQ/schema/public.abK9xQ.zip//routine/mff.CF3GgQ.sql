create function mff(a text, b text) returns text
    language plpgsql
as
$$
begin
  return 'b';
end;
$$;

alter function mff(text, text) owner to postgres;

