create function add_suffix_if_not_exists(str character varying, suffix character varying) returns character varying
    immutable
    language plpgsql
as
$$
begin
  if str like '%' || suffix
  then return str;
  else return str || suffix;
  end if;
end;
$$;

alter function add_suffix_if_not_exists(varchar, varchar) owner to postgres;

