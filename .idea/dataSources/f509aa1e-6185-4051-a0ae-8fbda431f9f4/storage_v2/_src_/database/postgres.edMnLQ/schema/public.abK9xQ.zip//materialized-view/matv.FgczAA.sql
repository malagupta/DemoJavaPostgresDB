create materialized view matv as
SELECT taba.id,
       taba.phrase
FROM taba;

alter materialized view matv owner to postgres;

create unique index matv_id_ui
    on matv (id);

create index matv_phrase_i
    on matv (phrase);

