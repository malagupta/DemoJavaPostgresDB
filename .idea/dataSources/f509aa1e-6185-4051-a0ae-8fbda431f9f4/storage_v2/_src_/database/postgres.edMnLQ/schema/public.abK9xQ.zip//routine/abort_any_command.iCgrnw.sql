create function abort_any_command() returns event_trigger
    language plpgsql
as
$$
BEGIN
  --   RAISE EXCEPTION 'command % is disabled', tg_tag;
END;
$$;

alter function abort_any_command() owner to postgres;

