create function to_string_with_plus(val integer) returns character varying
    immutable
    language plpgsql
as
$$
begin
  if val > 0
  then return '+' || val :: varchar;
  else return val :: varchar;
  end if;
end;
$$;

alter function to_string_with_plus(integer) owner to postgres;

