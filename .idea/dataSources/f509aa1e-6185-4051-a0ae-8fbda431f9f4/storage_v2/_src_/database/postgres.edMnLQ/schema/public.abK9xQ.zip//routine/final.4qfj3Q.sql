create function final(a text, b text, c text) returns text
    language plpgsql
as
$$
begin
  return a;
end
$$;

alter function final(text, text, text) owner to postgres;

