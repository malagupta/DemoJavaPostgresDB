create function _group_concat(a text) returns text
    language plpgsql
as
$$
begin
  return a;
end;
$$;

alter function _group_concat(text) owner to postgres;

