CREATE RULE rule_for_view AS
    ON INSERT TO view_with_rules DO INSTEAD ( INSERT INTO view_with_rules_t1 (ctr, ctr_name, ctr_capital)
  VALUES (new.ctr, new.ctr_name, new.cty);
 INSERT INTO view_with_rules_t2 (ctr, cty, cty_name, cty_is_capital)
  VALUES (new.ctr, new.cty, new.cty_name, true);
);

