create view view_with_rules(ctr, ctr_name, cty, cty_name) as
SELECT view_with_rules_t1.ctr,
       view_with_rules_t1.ctr_name,
       view_with_rules_t2.cty,
       view_with_rules_t2.cty_name
FROM view_with_rules_t1
         JOIN view_with_rules_t2 USING (ctr)
WHERE view_with_rules_t2.cty_is_capital;

alter table view_with_rules
    owner to postgres;

