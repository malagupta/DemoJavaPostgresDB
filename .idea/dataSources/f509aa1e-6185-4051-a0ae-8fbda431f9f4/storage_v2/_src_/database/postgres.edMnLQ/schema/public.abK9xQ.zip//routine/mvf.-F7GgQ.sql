create function mvf(a text, b text) returns text
    language plpgsql
as
$$
begin
  return 'a';
end;
$$;

alter function mvf(text, text) owner to postgres;

