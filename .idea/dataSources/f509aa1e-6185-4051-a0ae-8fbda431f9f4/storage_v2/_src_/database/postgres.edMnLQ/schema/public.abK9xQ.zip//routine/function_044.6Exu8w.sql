create function function_044()
    returns TABLE(x integer)
    language sql
as
$$
select 44
$$;

alter function function_044() owner to postgres;

