create function quote_it(s character varying) returns character varying
    immutable
    language plpgsql
as
$$
begin
  if s is not null
  then return '"' || s || '"';
  else return null;
  end if;
end;
$$;

alter function quote_it(varchar) owner to postgres;

