create function near(a integer, b integer) returns boolean
    immutable
    language plpgsql
as
$$
begin
  return a = b or a = b + 1 or b = a + 1;
end;
$$;

alter function near(integer, integer) owner to postgres;

