create function final(a text, b text) returns text
    language plpgsql
as
$$
begin
  return a;
end
$$;

alter function final(text, text) owner to postgres;

