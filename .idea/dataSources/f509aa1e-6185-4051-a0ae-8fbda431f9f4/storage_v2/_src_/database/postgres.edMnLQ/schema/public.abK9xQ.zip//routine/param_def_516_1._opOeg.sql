create function param_def_516_1(p1 integer DEFAULT 1, p2 character varying DEFAULT 'some text'::character varying) returns integer
    language plpgsql
as
$$
begin
  return p1 + length(p2);
end;
$$;

alter function param_def_516_1(integer, varchar) owner to postgres;

