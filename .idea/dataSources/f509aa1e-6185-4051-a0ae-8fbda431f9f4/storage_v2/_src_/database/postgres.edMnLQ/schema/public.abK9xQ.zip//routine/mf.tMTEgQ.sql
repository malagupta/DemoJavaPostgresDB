create function mf(a text, b text) returns text
    language plpgsql
as
$$
begin
  return 'c';
end;
$$;

alter function mf(text, text) owner to postgres;

